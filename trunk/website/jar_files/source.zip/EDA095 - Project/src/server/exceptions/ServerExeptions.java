package server.exceptions;

public abstract class ServerExeptions extends Exception {

}
