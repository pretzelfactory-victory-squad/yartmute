package server.exceptions;

public class OutOfSyncException extends ServerExeptions{
		
	public OutOfSyncException(){
	}

}
